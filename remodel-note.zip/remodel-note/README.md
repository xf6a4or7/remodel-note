# remodel-note

인테리어 상담·통화 녹취를 업로드하면 **STT → 용어 교정 → 구조화 분석 → 회의록/요구사항 문서**까지 자동으로 만들어주는 파이프라인.

## 흐름

```
audio/ (음성)
  → STT (CLOVA Speech / Whisper 교체 가능)
  → 용어 사전 치환 + Claude 문맥 교정
  → Claude 구조화 분석 (공간별·자재별 요구사항 태깅)
  → output/
       ├─ *_회의록.docx     (개요·결정·미결·요청·액션·견적)
       ├─ *_요구사항.json
       └─ *_요약.md
```

## 설치

```bash
pip install -r requirements.txt
cp .env.example .env   # 그리고 .env 에 키 입력
```

## 환경변수(.env)

| 변수 | 설명 |
|------|------|
| `CLOVA_SPEECH_INVOKE_URL` | NCP CLOVA Speech 도메인의 Invoke URL |
| `CLOVA_SPEECH_SECRET` | CLOVA Speech Secret Key |
| `ANTHROPIC_API_KEY` | Claude API 키 (교정·분석용) |
| `STT_ENGINE` | `clova`(기본) 또는 `whisper` |

> NCP 콘솔에서 CLOVA Speech 도메인을 만들면 Invoke URL과 Secret이 발급됩니다.
> 로컬 파일 업로드 방식(`/recognizer/upload`)을 쓰므로 Object Storage 없이도 동작합니다.

## 사용

```bash
python cli.py audio/녹취.m4a
python cli.py audio/녹취.m4a --no-claude       # STT + 사전 치환만
python cli.py audio/녹취.m4a --engine whisper  # 엔진 교체
```

## 용어 사전

`config/glossary.json` 에 현장 용어 오인식 교정 규칙이 있습니다.
새 오인식을 발견하면 `"잘못된표현": "올바른표현"` 형태로 계속 추가하세요.
이 단어들은 CLOVA Speech 부스팅 키워드로도 자동 활용되어 인식률을 높입니다.

## 구조

```
remodel-note/
├─ cli.py                 진입점
├─ config/glossary.json   용어 교정 사전
├─ src/
│  ├─ stt/                STT 엔진 (base/clova/whisper, 교체 가능)
│  ├─ postprocess.py      용어 치환 + Claude 교정
│  ├─ analyze.py          구조화 분석
│  ├─ docgen.py           회의록 docx 생성
│  └─ pipeline.py         전체 오케스트레이션
├─ audio/                 입력 음성 (git 제외)
├─ transcripts/           중간 산출물 (git 제외)
└─ output/                최종 산출물 (git 제외)
```

## 개인정보 주의

`audio/`, `transcripts/`, `output/`, `.env` 는 `.gitignore` 로 깃에서 제외됩니다.
**고객 녹취·전사본·회의록은 절대 커밋되지 않습니다.** 코드만 버전관리됩니다.
